Synthetic example input. Run python rainfall.py --data inputs/demo-weather.csv to exercise CSV mode.
