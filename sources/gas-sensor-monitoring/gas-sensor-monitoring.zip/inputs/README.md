Seeded synthetic signals used by the default generator. For measured data use the UCI batch file interface described in README.md.
